package com.lianbei.httplbrary.interfaces;

/**
 * Created by 耿 on 2016/8/15.
 */
@FunctionalInterface
public interface Fail {
    void Fail(String model);
}

package com.lianbei.httplbrary;

/**
 * Created by chen_yxin on 2017/3/2.
 */

/**
 * 返回数据公共数据Model
 */
public class ApiResultModel {
    /**
    /**
     * 返回标识
     */
    private String return_code; //SUCCESS   //400
    private String code;
    private String return_msg; //0000
    private Object data;

    public String getReturn_code() {
        return return_code;
    }

    public void setReturn_code(String return_code) {
        this.return_code = return_code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getReturn_msg() {
        return return_msg;
    }

    public void setReturn_msg(String return_msg) {
        this.return_msg = return_msg;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}

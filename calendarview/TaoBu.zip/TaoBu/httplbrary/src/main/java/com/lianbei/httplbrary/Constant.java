package com.lianbei.httplbrary;

/**
 * Created by Administrator on 2016/12/21.
 */

public class Constant {
    public static final String DOWNLOAD = "DOWNLOAD";
    public static final String DOWNLOAD_URL = "DOWNLOAD_URL";
}

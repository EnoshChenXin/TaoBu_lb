package com.lianbei.httplbrary.interfaces;

import java.util.Map;

/**
 * Created by Administrator on 2016/11/23.
 */
public interface HeadersInterceptor {
    Map checkHeaders(Map headers);
}

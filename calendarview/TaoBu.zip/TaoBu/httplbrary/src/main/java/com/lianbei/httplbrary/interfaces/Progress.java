package com.lianbei.httplbrary.interfaces;

/**
 * Created by Administrator on 2016/12/21.
 */
@FunctionalInterface
public interface Progress {
    void progress(float p);
}

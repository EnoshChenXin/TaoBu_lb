package com.lianbei.taobu.taobu.viewmanager;

import android.app.Activity;

import com.lianbei.httplbrary.HttpUtil;
import com.lianbei.httplbrary.interfaces.Error;
import com.lianbei.httplbrary.interfaces.Fail;
import com.lianbei.httplbrary.interfaces.Success;
import com.lianbei.taobu.api.APIs;
import com.lianbei.taobu.listener.RequestCompletion;
import com.lianbei.taobu.taobu.model.CommodityBean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TaoBuManager {

    private Activity mContext;

    public TaoBuManager( Activity mContext){
        this.mContext = mContext;
    }

    public void GetCommodityContent(RequestCompletion completion) {
        this.requestCompletion = completion;
        Map<String,String> map = new HashMap <> (  );
        new HttpUtil.Builder ( APIs.BASE_URL )
                .Params ( map )
                .Tag (mContext )
                .Success ( new Success ( ) {
                    @Override
                    public void Success(String model) {

                    }
                } ).Error ( new Error ( ) {
            @Override
            public void Error(Object... values) {

            }
        } ).Fail ( new Fail ( ) {
            @Override
            public void Fail(String model) {

            }
        } ).post ();

    }
    public void GetCommodityContent(RequestCompletion completion,String ser) {
            this.requestCompletion = completion;
            List <CommodityBean> commodityBeans = new ArrayList <> ( );
            CommodityBean commodityBean = new CommodityBean ();
            commodityBean.setTitle ( "嗨吃家酸辣粉红薯粉6桶*113g整箱网红速食方便面粉丝重庆风味夜宵" );
            commodityBean.setDescribe ( "兑换人数：556" );
            commodityBean.setPrice ( "869" );
            commodityBeans.add (commodityBean );


            CommodityBean commodityBean1 = new CommodityBean ();
            commodityBean1.setTitle ( "30包/8包丝飘天然竹浆本色纸巾抽纸批发整箱家用卫生纸面巾纸抽【预售：8月4日发完】" );
            commodityBean1.setDescribe ( "兑换人数：34" );
            commodityBean1.setPrice ( "189" );
            commodityBeans.add (commodityBean1 );

            CommodityBean commodityBean2 = new CommodityBean ();
            commodityBean2.setTitle ( "千丝乳酸菌小口袋面包早餐手撕蛋糕吐司好吃的网红零食品休闲小吃" );
            commodityBean2.setDescribe ( "兑换人数：456" );
            commodityBean2.setPrice ( "859" );
            commodityBeans.add (commodityBean2 );

            CommodityBean commodityBean3 = new CommodityBean ();
            commodityBean3.setTitle ( "居家凉拖鞋女夏季室内防滑男家居软底浴室洗澡家用外穿拖鞋情侣" );
            commodityBean3.setDescribe ( "兑换人数：74" );
            commodityBean3.setPrice ( "53" );
            commodityBeans.add (commodityBean3 );

            CommodityBean commodityBean4 = new CommodityBean ();
            commodityBean4.setTitle ( "正宗陕西大荔大荔冬枣新鲜应季水果冬枣脆甜冬枣鲜枣红枣1/4斤装" );
            commodityBean4.setDescribe ( "兑换人数：456" );
            commodityBean4.setPrice ( "785" );
            commodityBeans.add (commodityBean4 );

            CommodityBean commodityBean5 = new CommodityBean ();
            commodityBean5.setTitle ( "恒澍洗碗海绵擦百洁布不沾油金刚砂魔力清洁洗锅用品厨房刷碗神器" );
            commodityBean5.setDescribe ( "兑换人数：356" );
            commodityBean5.setPrice ( "435" );
            commodityBeans.add (commodityBean5 );
        if(requestCompletion != null){
            requestCompletion.Success ( commodityBeans,"" );
        }

    }
    private RequestCompletion requestCompletion = null;

    public interface RequestCompletion{
        void Success(Object value,String tag);
        void Fail(Object value);//业务上的400
        void Error(Object... values);//网络问题、超时、连不上服务器 404等
    }
}

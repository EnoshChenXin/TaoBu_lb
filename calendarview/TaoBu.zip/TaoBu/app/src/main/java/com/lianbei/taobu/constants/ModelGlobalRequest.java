package com.lianbei.taobu.constants;

/**
 * Created by HASEE on 2017/3/17.
 */

/**
 * 公共异常数据模型
 */

public class ModelGlobalRequest {

   private String return_code;
   private String code;
   private String return_msg;
   private Object data;


    public String getReturn_code() {
        return return_code;
    }

    public void setReturn_code(String return_code) {
        this.return_code = return_code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getReturn_msg() {
        return return_msg;
    }

    public void setReturn_msg(String return_msg) {
        this.return_msg = return_msg;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}

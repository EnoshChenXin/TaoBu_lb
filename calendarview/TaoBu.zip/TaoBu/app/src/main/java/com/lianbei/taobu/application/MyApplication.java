package com.lianbei.taobu.application;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.support.multidex.MultiDex;
import android.util.DisplayMetrics;
import android.webkit.WebView;

import com.lianbei.httplbrary.HttpUtil;
import com.lianbei.httplbrary.interfaces.ParamsInterceptor;
import com.lianbei.taobu.BuildConfig;
import com.lianbei.taobu.api.APIs;
import com.lianbei.taobu.utils.DisplayUtil;
import com.lianbei.taobu.utils.log.KLog;
import com.tencent.bugly.crashreport.CrashReport;

import java.util.Map;

/**
 * Created by NEUNB on 2018/3/19.
 */

public class MyApplication extends Application {
    //以下属性应用于整个应用程序，合理利用资源，减少资源浪费
    private static MyApplication myApplication;
    public static Context sContext;
    private static Context mContext;//上下文
    private static Thread mMainThread;//主线程
    private static long mMainThreadId;//主线程id
    private static Looper mMainLooper;//循环队列
    private static Handler mHandler;//主线程Handler

    @Override
    public void onCreate() {
        super.onCreate ( );
        //对全局属性赋值
        KLog.init( BuildConfig.DEBUG);//初始化KLog
        mContext = getApplicationContext();
        mMainThread = Thread.currentThread();
        mMainThreadId = android.os.Process.myTid();
        mHandler = new Handler();
        initDisplayOpinion();

        //腾讯bugly 测试阶段建议设置成true，发布时设置为false
        CrashReport.initCrashReport ( getApplicationContext ( ), "5b1efae7da", false );
        //百度

        try {
            // API 19（4.4）, only for debug
            if (Build.VERSION.SDK_INT >= 19) {
                WebView.class.getMethod ( "setWebContentsDebuggingEnabled", boolean.class ).invoke ( null, true );
            }
        } catch (Exception e) {
            e.printStackTrace ( );
        }
         new HttpUtil.SingletonBuilder(this)
         .baseUrl( APIs.BASE_URL)//URL请求前缀地址。必传
         //                .versionApi("")//API版本，不传不可以追加接口版本号
         //                .addServerUrl("")//备份服务器ip地址，可多次调用传递
         //                .addCallFactory()//不传默认StringConverterFactory
         //                .addConverterFactory()//不传默认RxJavaCallAdapterFactory
         //                .client()//OkHttpClient,不传默认OkHttp3
         .paramsInterceptor(mParamsInterceptor)//不传不进行参数统一处理
         //.headersInterceptor(mHeadersInterceptor)//不传不进行headers统一处理
         .build();
    }
    ParamsInterceptor mParamsInterceptor = new ParamsInterceptor ( ) {
        @Override
        public Map checkParams(Map params) {
           //  String userid = (String) SPUtils.get ("user_id", "" );
          //  params.put ("userId", UserInfo.getUserInfo (getContext ()).getUser_id () );
           // params.put("token", Security.encrypt ( TimeUtils.getTime ())+"");
            return params;
        }
    };

    /**
     * 全程作用域
     *
     * @return
     */
    public static MyApplication getApplication() {
        return myApplication;
    }

    /***
     * 注册微信
     */
    private void registToWX() {
        //AppConst.WEIXIN.APP_ID是指你应用在微信开放平台上的AppID，记得替换。
      /*  mWxApi = WXAPIFactory.createWXAPI(this, apiConstant.APP_ID, false);
        // 将该app注册到微信
        mWxApi.registerApp(apiConstant.APP_ID);*/
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext ( base );
        MultiDex.install ( this );
    }

    private void initDisplayOpinion() {
        DisplayMetrics dm = getResources ( ).getDisplayMetrics ( );
        DisplayUtil.density = dm.density;
        DisplayUtil.densityDPI = dm.densityDpi;
        DisplayUtil.screenWidthPx = dm.widthPixels;
        DisplayUtil.screenhightPx = dm.heightPixels;
        DisplayUtil.screenWidthDip = DisplayUtil.px2dip ( getApplicationContext ( ), dm.widthPixels );
        DisplayUtil.screenHightDip = DisplayUtil.px2dip ( getApplicationContext ( ), dm.heightPixels );
    }
    /**
     * 重启当前应用
     */
    public static void restart() {
        Intent intent = mContext.getPackageManager().getLaunchIntentForPackage(mContext.getPackageName());
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        mContext.startActivity(intent);
    }

    public static Context getContext() {
        return mContext;
    }

    public static void setContext(Context mContext) {
        MyApplication.mContext = mContext;
    }

    public static Thread getMainThread() {
        return mMainThread;
    }

    public static void setMainThread(Thread mMainThread) {
        MyApplication.mMainThread = mMainThread;
    }

    public static long getMainThreadId() {
        return mMainThreadId;
    }

    public static void setMainThreadId(long mMainThreadId) {
        MyApplication.mMainThreadId = mMainThreadId;
    }

    public static Looper getMainThreadLooper() {
        return mMainLooper;
    }

    public static void setMainThreadLooper(Looper mMainLooper) {
        MyApplication.mMainLooper = mMainLooper;
    }

    public static Handler getMainHandler() {
        return mHandler;
    }

    public static void setMainHandler(Handler mHandler) {
        MyApplication.mHandler = mHandler;
    }

}

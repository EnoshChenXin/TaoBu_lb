package com.lianbei.taobu.circle.view;

import com.lianbei.taobu.R;
import com.lianbei.taobu.base.BaseFragment;
public class CircleFragment extends BaseFragment {
    @Override
    public int getContentViewId() {
        return R.layout.fragment_circle;
    }

    @Override
    public void initViews() {

    }

    @Override
    public void initData() {

    }

    @Override
    public void initListener() {

    }
}

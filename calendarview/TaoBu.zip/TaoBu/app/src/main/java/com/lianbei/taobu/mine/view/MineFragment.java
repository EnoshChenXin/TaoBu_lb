package com.lianbei.taobu.mine.view;

import android.net.Uri;

import com.lianbei.taobu.R;
import com.lianbei.taobu.base.BaseFragment;

public class MineFragment extends BaseFragment {


    @Override
    public int getContentViewId() {
        return R.layout.fragment_mine;
    }

    @Override
    public void initViews() {

    }

    @Override
    public void initData() {

    }

    @Override
    public void initListener() {

    }
}

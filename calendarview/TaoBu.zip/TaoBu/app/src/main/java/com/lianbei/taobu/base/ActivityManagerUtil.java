package com.lianbei.taobu.base;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.util.Log;

import java.util.Stack;

/**
 * Created by HASEE on 2017/3/27.
 */

public class ActivityManagerUtil {
    private static Stack<Activity> activityStack;
    private static ActivityManagerUtil instance;

    private ActivityManagerUtil(){}
    /**
     * 单一实例
     */
    public static ActivityManagerUtil getInstance(){
        if(instance==null){
            instance=new ActivityManagerUtil();
        }
        return instance;
    }
    /**
     * 添加Activity到堆栈
     */
    public void addActivity(Activity activity){
        if(activityStack==null){
            activityStack=new Stack<Activity> ();
        }
        activityStack.add(activity);
    }
    /**
     * 获取当前Activity（堆栈中最后一个压入的）
     */
    public Activity currentActivity(){
        if(activityStack != null && activityStack.size()>0){
            Activity activity=activityStack.lastElement();
            return activity;
        }else{
            return null;
        }
    }

    /**
     * 从当前Activity开始一直往前item个Activity全部finish
     * @param item 往前多少个Activity(不包括item本身)
     */
    public void finishActivityToActivity(int item){
        int index = activityStack.size() - 1;
        if (item <= index){
            for (int i = 0; i < item; i++){
                Activity activity = activityStack.get(index - i);
                finishActivity(activity);
            }
        }else {
            Log.e("AcitiviyManager", "超出范围");
        }
    }

    /**
     * 从stack中将当前Activity与符合cls类名的所有的Activity全部finish,包括当前Activity
     * 从当前Activity开始finish一直到指定的clss类的Activity
     */
    public void finishActivityToActivity(Class<?> cls){
        Stack<Activity> temp = new Stack<Activity> ();//用于记录需要移除并finish的activity
        for (Activity activity : activityStack) {
            if(activity.getClass().equals(cls) ){
                break;
            }else {
                temp.add(activity);
            }
        }
        for (Activity activity:temp){
            finishActivity(activity);
        }
    }

    /**
     * 从stack中将当前Activity与activity中所有的Activity全部finish,包括当前Activity
     */
    public void finishActivityToActivity(Activity activity){
        if (activityStack.contains(activity)){
            finishActivityToActivity(activityStack.indexOf(activity));
        }
    }
    /**
     * 结束当前Activity（堆栈中最后一个压入的）
     */
    public void finishActivity(){
        Activity activity= currentActivity();
        if (activity != null){
            activityStack.remove(activity);
            activity = null;
        }
    }
    /**
     * 结束指定的Activity
     */
    public void finishActivity(Activity activity){
        if(activity!=null){
            activity.finish();
        }
    }
    /**
     * 结束指定类名的Activity
     */
    public void finishActivity(Class<?> cls){
        for (Activity activity : activityStack) {
            if(activity.getClass().equals(cls) ){
                finishActivity(activity);
            }
        }
    }
    /**
     * 结束所有Activity
     */
    public void finishAllActivity(){
        for (int i = 0, size = activityStack.size(); i < size; i++){
            if (null != activityStack.get(i)){
                activityStack.get(i).finish();
            }
        }
        activityStack.clear();
    }
    /**
     * 退出应用程序
     */
    public void AppExit(Context context) {
        try {
            finishAllActivity();
            ActivityManager activityMgr= (ActivityManager) context.getSystemService( Context.ACTIVITY_SERVICE);
            activityMgr.restartPackage(context.getPackageName());
            System.exit(0);
        } catch (Exception e) { }
    }
}

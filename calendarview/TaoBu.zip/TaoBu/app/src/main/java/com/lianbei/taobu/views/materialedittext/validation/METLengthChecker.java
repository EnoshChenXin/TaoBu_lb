package com.lianbei.taobu.views.materialedittext.validation;

/**
 * Created by mariotaku on 15/4/12.
 */
public abstract class METLengthChecker {

    public abstract int getLength(CharSequence text);

}

package com.lianbei.taobu.utils;

import android.app.Activity;

import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TimeUtils {
    private static String TAG = "TimeUtils";


    public static int compare_date(String DATE1, String DATE2) {
        SimpleDateFormat df = new SimpleDateFormat ( "yyyy-MM-dd hh:mm:ss" );
        try {
            Date dt1 = df.parse ( DATE1 );
            Date dt2 = df.parse ( DATE2 );
            if (dt1.getTime ( ) > dt2.getTime ( )) {
                return 1;
            } else if (dt1.getTime ( ) < dt2.getTime ( )) {
                return -1;
            } else {
                return 0;
            }
        } catch (Exception exception) {
            exception.printStackTrace ( );
        }
        return -2;
    }

    public static int compare_Stringdate(String DATE1, String DATE2) {
        try {
            if (DATE1.compareTo ( DATE2 ) > 0) {
                return 1;
            } else {
                return -1;
            }
        } catch (Exception e) {
            e.printStackTrace ( );
        }
        return -2;
    }


    private void time() {
        SimpleDateFormat formatter = new SimpleDateFormat ( "yyyy年MM月dd日 HH:mm:ss" );
        Date curDate = new Date ( System.currentTimeMillis ( ) );
        //获取当前时间
        String str = formatter.format ( curDate );
    }

    //字符串转时间戳
    public static String getTime(String timeString) {
        String timeStamp = null;
        SimpleDateFormat sdf = new SimpleDateFormat ( "yyyy-MM-dd HH:mm:ss" );
        Date d;
        try {
            d = sdf.parse ( timeString );
            long l = d.getTime ( );
            timeStamp = String.valueOf ( l );
        } catch (ParseException e) {
            e.printStackTrace ( );
        }
        return timeStamp;
    }

    public static String getNetTime() {
        URL url = null;  //取得资源对象
        try {
            url = new URL ( "http://www.baidu.com" );
            // url = new URL("http://www.ntsc.ac.cn");
            //中国科学院国家授时中心
            //  url = new URL("http://www.bjtime.cn");
            URLConnection uc = url.openConnection ( ); //生成连接对象
            uc.connect ( ); //发出连接
            long ld = uc.getDate ( );//取得网站日期时间
            // 取得网站日期时间
            DateFormat formatter = new SimpleDateFormat ( "yyyy-MM-dd HH:mm:ss" );
            Calendar calendar = Calendar.getInstance ( );
            calendar.setTimeInMillis ( ld );
            final String format = formatter.format ( calendar.getTime ( ) );
            return format;
        } catch (Exception e) {
            e.printStackTrace ( );
            return "2008-01-01 23:59:59";
        }
    }

    public static String getLocalTime() {
        URL url = null;
        //取得资源对象
        try {
            DateFormat formatter = new SimpleDateFormat ( "yyyy-MM-dd HH:mm:ss" );
            Calendar calendar = Calendar.getInstance ( );
            calendar.setTimeInMillis ( System.currentTimeMillis ( ) );
            String format = formatter.format ( calendar.getTime ( ) );
            return format;
        } catch (Exception e) {
            e.printStackTrace ( );
            return "2008-01-01 23:59:59";
        }
    }


    /**
     * 用户操作数据
     *
     * @param DATE1
     * @param DATE2
     * @return
     */
    private String setOperationTime = "";


}
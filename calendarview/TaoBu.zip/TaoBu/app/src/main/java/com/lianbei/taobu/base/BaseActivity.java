package com.lianbei.taobu.base;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.widget.Toast;

import com.alibaba.android.arouter.launcher.ARouter;
import com.chaychan.lib.SlidingLayout;
import com.lianbei.httplbrary.utils.ApiRequestParamInterface;
import com.lianbei.taobu.MainActivity;
import com.lianbei.taobu.utils.ActivityUtils;
import com.lianbei.taobu.constants.GlobalRequestManage;

import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.ButterKnife;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;


/**
 * Created by SilenceDut on 16/10/15.
 */

public abstract class BaseActivity extends AppCompatActivity implements NavigationView.onNavigationBarClickListener,BaseViewInit , ApiRequestParamInterface {
    private boolean isExit=false;
    public NavigationView navigationView;
    private boolean DEBUG = true;
    @Override
    protected void attachBaseContext(Context newBase) {
       super.attachBaseContext( CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Router.instance().register(this);
        //添加Activity到堆栈
        ActivityUtils.getAppManager().addActivity(this);
        initBeforeView();
        if (enableSlideClose()) {
            SlidingLayout rootView = new SlidingLayout(this);
            rootView.bindActivity(this);
        }
        setContentView(getContentViewId());
        ActivityManagerUtil.getInstance().addActivity(this);
        ButterKnife.bind(this);
        initViews();
        initData();
        initListener();
        initDataObserver();
    }
    //跳转的方法
    public void jumpActivity(Context context, Class <?> targetActivity) {
        Intent intent = new Intent ( context, targetActivity );
        startActivity ( intent );
    }
    private void initARouter() {
        //ARouter
        if (DEBUG) {           // 这两行必须写在init之前，否则这些配置在init过程中将无效
            ARouter.openLog();     // 打印日志
            ARouter.openDebug();   // 开启调试模式(如果在InstantRun模式下运行，必须开启调试模式！线上版本需要关闭,否则有安全风险)
        }
        ARouter.init(this.getApplication()); // 尽可能早，推荐在Application中初始化
    }
    protected void initDataObserver() {

    }

    @Override
    protected void onResume() {
        super.onResume();
        initARouter();
        //友盟统计分析——session统计
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            exitBy2Click ( );
            return true;
        }
        return false;
    }
    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    public void initBeforeView() {
        initARouter();
    }
    public void createNavigationView(@IdRes int id){
        navigationView = (NavigationView)findViewById(id);
        navigationView.setNavigationBarClickListener(this);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(menuItem);
    }
    public boolean enableSlideClose() {
        return true;
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        //结束Activity&从堆栈中移除
        ActivityUtils.getAppManager().finishActivity(this);
        //Router.instance().unregister(this);
    }
    @Override
    public String RequestParam() {
        return null;
    }

    @Override
    public Map<String, String> parammap() {
        return null;
    }

    @Override
    public void result(Object object) {
        GlobalRequestManage.getInstance(this).apiResult(object);
    }
    /**
     * 双击退出函数
     */
    private void exitBy2Click() {
        Timer tExit = null;
        if (getClass ( ).getName ( ).equals ( MainActivity.class.getName ( ) )) {
            if (isExit == false) {
                isExit = true; // 准备退出
                Toast.makeText ( this, "再按一次，退出程序", Toast.LENGTH_SHORT ).show ( );
                tExit = new Timer ( );
                tExit.schedule ( new TimerTask ( ) {
                    @Override
                    public void run() {
                        isExit = false; // 取消退出
                    }
                }, 2000 ); // 如果2秒钟内没有按下返回键，则启动定时器取消掉刚才执行的任务
            } else {
                //System.exit(0);
                // moveTaskToBack(true);
               // ListActivity.closeAll ( );
                ActivityUtils.getAppManager().AppExit(this);
                finish ( );
            }
        } else {
            finish ( );
        }
    }
}

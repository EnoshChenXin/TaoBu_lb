package com.lianbei.taobu.taobu.view;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chaychan.uikit.powerfulrecyclerview.PowerfulRecyclerView;
import com.lianbei.taobu.R;
import com.lianbei.taobu.base.BaseFragment;
import com.lianbei.taobu.taobu.adapter.CommodityListAdapter;
import com.lianbei.taobu.taobu.adapter.GridViewAdapter;
import com.lianbei.taobu.taobu.model.CommodityBean;
import com.lianbei.taobu.taobu.view.viewutils.LinearGradientUtil;
import com.lianbei.taobu.taobu.view.viewutils.MastGridView;
import com.lianbei.taobu.taobu.viewmanager.TaoBuManager;
import com.lianbei.taobu.utils.TimeUtils;
import com.lianbei.taobu.views.CircleBarView;
import android.support.v7.widget.GridLayoutManager;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class TaobuFragment extends BaseFragment implements View.OnClickListener,
        TaoBuManager.RequestCompletion {

    @BindView(R.id.btn_restart)
    Button btnRestart;
    @BindView ( R.id.circle_view)
    CircleBarView circleBarView;

    @BindView ( R.id.text_progress)
    TextView textProgress;

    private int num;
    private float progressNum;
    /*@BindView(R.id.sc)
    public SmartScrollView sc;*/
    @BindView ( R.id.tv_title_bar )
    TextView tv_title_bar;
    @BindView ( R.id.upload_btn )
    LinearLayout upload_btn;
    @BindView(R.id.rv_news)
    PowerfulRecyclerView mRvNews;
    @BindView(R.id.mastgridview)
    MastGridView mastgridview;

    @BindView ( R.id.daka_btn )//打卡
    ImageView daka_btn;

    @BindView ( R.id.walk_btn )//走呗
    ImageView walk_btn;
    @BindView ( R.id.huanwu_btn ) //糖豆换物
    ImageView huanwu_btn;

    private String mChannelCode = "0";
    protected BaseQuickAdapter commodityAdapter;
    private List <CommodityBean> commodityBeans = new ArrayList <> ( );
    TaoBuManager taoBuManager;


    @Override
    public int getContentViewId() {
        return R.layout.fragment_taobu;
    }

    @Override
    public void initViews() {
        tv_title_bar.setText ( TimeUtils.getLocalTime ()+"" );
        circleBarView.setTextView(textProgress);
        circleBarView.setMaxNum ( 6000 );
        progressNum = 4586;
        circleBarView.setOnAnimationListener(new CircleBarView.OnAnimationListener() {
            @Override
            public String howToChangeText(float interpolatedTime, float updateNum, float maxNum) {
                DecimalFormat decimalFormat=new DecimalFormat("0");
               // String s = decimalFormat.format(interpolatedTime * updateNum / maxNum * 100)+"%";
                String s = decimalFormat.format(interpolatedTime * updateNum);
                return s;
            }
            @Override
            public void howTiChangeProgressColor(Paint paint, float interpolatedTime, float updateNum, float maxNum) {
                LinearGradientUtil linearGradientUtil = new LinearGradientUtil ( Color.YELLOW,Color.RED);
                paint.setColor(linearGradientUtil.getColor(interpolatedTime));
            }
        });
        circleBarView.setProgressNum(progressNum,2000);

        num = 0;
        setProgressNumInThread();
        btnRestart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                circleBarView.setProgressNum(progressNum,2000);
                setProgressNumInThread();
            }
        });
        setListView();
    }

    private void setListView(){

        mRvNews.setLayoutManager ( new GridLayoutManager ( mActivity, 1 ) );
        mRvNews.setNestedScrollingEnabled ( false );//解决滑动卡顿

    }

    private Handler handler=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case 0:
                    //circleBarView2.setProgressNum(num,0);
                    break;
            }
        }
    };
    private void setProgressNumInThread(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    for (int i=1;i<=100;i++){
                        num = i;
                        handler.obtainMessage(0).sendToTarget();
                        Thread.sleep(50);
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    @Override
    public void initData() {
        taoBuManager = new TaoBuManager ( this.getActivity () );
        taoBuManager.GetCommodityContent (  this,"");

        //请求....

    }

    @Override
    public void initListener() {
        commodityAdapter = new CommodityListAdapter ( mChannelCode, commodityBeans );
        mRvNews.setAdapter ( commodityAdapter );
        commodityAdapter.setOnItemClickListener ( new BaseQuickAdapter.OnItemClickListener ( ) {
            @Override
            public void onItemClick(BaseQuickAdapter baseQuickAdapter, View view, int i) {

            }
        } );

        upload_btn.setOnClickListener ( new View.OnClickListener ( ) {
            @Override
            public void onClick(View view) {
                circleBarView.setProgressNum(progressNum,2000);
                setProgressNumInThread();
            }
        } );
    }

    @OnClick({R.id.daka_btn,R.id.walk_btn,R.id.huanwu_btn})
    @Override
    public void onClick(View view) {
        switch (view.getId ( )) {
            case  R.id.daka_btn:
                Intent intent = new Intent (  this.getActivity (),WalkActivity.class);
                startActivity (intent );
                break;
            case  R.id.walk_btn:
                Intent intents = new Intent (  this.getActivity (),WalkActivity.class);
                startActivity (intents );
                break;

            case  R.id.huanwu_btn:
                Intent intentss = new Intent (  this.getActivity (),HuanWuActivity.class);
                startActivity (intentss );
                break;


        }

    }

    @Override
    public void Success(Object value, String tag) {
        try {
            if(value != null){
                commodityBeans = (ArrayList <CommodityBean>)value;
             //   commodityAdapter.notifyDataSetChanged ();

                //

                DisplayMetrics dm = new DisplayMetrics();
                this.getActivity ().getWindowManager().getDefaultDisplay().getMetrics(dm);
                float density = dm.density;

                int gridviewWidth = (int) (commodityBeans.size () * (100 + 4) * density);
                int itemWidth = (int) (100 * density);
                GridViewAdapter adapter = new GridViewAdapter(this.getContext (),
                        commodityBeans);
                mastgridview.setDataSize ( commodityBeans.size (), gridviewWidth,itemWidth);
                mastgridview.setAdapter(adapter);
                //
            }
        } catch (Exception e) {
            e.printStackTrace ( );
        }
    }

    @Override
    public void Fail(Object value) {

    }

    @Override
    public void Error(Object... values) {

    }


}
